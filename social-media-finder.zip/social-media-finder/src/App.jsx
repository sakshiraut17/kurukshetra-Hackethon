import React, { useState } from 'react';
import { Search, User, Mail, Phone, MapPin, Calendar, Download, Shield, Eye, Users, MessageCircle, ExternalLink, Globe, Heart, Share, Camera, Video } from 'lucide-react';

const SocialMediaFinder = () => {
  const [searchInput, setSearchInput] = useState('');
  const [searchType, setSearchType] = useState('username');
  const [results, setResults] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');

  // Enhanced platform data with real social media links structure
  const platformsData = [
    { name: 'Facebook', icon: '📘', baseUrl: 'https://facebook.com/', color: 'from-blue-600 to-blue-800' },
    { name: 'Instagram', icon: '📸', baseUrl: 'https://instagram.com/', color: 'from-pink-600 to-purple-700' },
    { name: 'Twitter', icon: '🐦', baseUrl: 'https://twitter.com/', color: 'from-sky-500 to-blue-600' },
    { name: 'LinkedIn', icon: '💼', baseUrl: 'https://linkedin.com/in/', color: 'from-blue-700 to-indigo-800' },
    { name: 'TikTok', icon: '🎵', baseUrl: 'https://tiktok.com/@', color: 'from-red-500 to-pink-600' },
    { name: 'YouTube', icon: '📺', baseUrl: 'https://youtube.com/@', color: 'from-red-600 to-red-800' },
    { name: 'Snapchat', icon: '👻', baseUrl: 'https://snapchat.com/add/', color: 'from-yellow-400 to-yellow-600' },
    { name: 'Pinterest', icon: '📌', baseUrl: 'https://pinterest.com/', color: 'from-red-500 to-pink-500' },
    { name: 'Reddit', icon: '🗨️', baseUrl: 'https://reddit.com/u/', color: 'from-orange-500 to-red-600' },
    { name: 'Discord', icon: '🎮', baseUrl: 'https://discord.com/users/', color: 'from-indigo-600 to-purple-700' },
    { name: 'Telegram', icon: '✈️', baseUrl: 'https://t.me/', color: 'from-blue-400 to-cyan-500' },
    { name: 'WhatsApp', icon: '💬', baseUrl: 'https://wa.me/', color: 'from-green-500 to-emerald-600' }
  ];

  // Validation functions
  const validatePhone = (phone) => {
    const phoneRegex = /^\d{10}$/;
    return phoneRegex.test(phone.replace(/\D/g, ''));
  };

  const validateEmail = (email) => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  };

  const generateConsistentData = (input, type) => {
    let baseName, baseEmail, basePhone, username;

    // Generate consistent data based on input type
    if (type === 'phone') {
      if (!validatePhone(input)) {
        throw new Error('Please enter a valid 10-digit phone number');
      }
      basePhone = input.replace(/\D/g, '');
      const nameVariations = ['John Doe', 'Sarah Johnson', 'Mike Wilson', 'Emily Davis', 'Chris Brown', 'Jessica Taylor'];
      baseName = nameVariations[parseInt(basePhone.slice(-1)) % nameVariations.length];
      baseEmail = `${baseName.toLowerCase().replace(' ', '.')}@gmail.com`;
      username = `${baseName.toLowerCase().replace(' ', '_')}_${basePhone.slice(-4)}`;
    } else if (type === 'email') {
      if (!validateEmail(input)) {
        throw new Error('Please enter a valid email address');
      }
      baseEmail = input;
      const emailPrefix = input.split('@')[0];
      baseName = emailPrefix.replace(/[._\-\d]/g, ' ')
        .split(' ')
        .map(word => word.charAt(0).toUpperCase() + word.slice(1))
        .join(' ') || 'Anonymous User';
      basePhone = `${Math.floor(Math.random() * 900) + 100}${Math.floor(Math.random() * 900) + 100}${Math.floor(Math.random() * 9000) + 1000}`;
      username = emailPrefix;
    } else {
      // Username type
      if (input.length < 3) {
        throw new Error('Username must be at least 3 characters long');
      }
      username = input.toLowerCase();
      baseName = input.split(/[._\-]/).map(word =>
        word.charAt(0).toUpperCase() + word.slice(1)
      ).join(' ');
      basePhone = `${Math.floor(Math.random() * 900) + 100}${Math.floor(Math.random() * 900) + 100}${Math.floor(Math.random() * 9000) + 1000}`;
      baseEmail = `${username}@gmail.com`;
    }

    // Locations and companies for variety
    const locations = [
      'New York, NY', 'Los Angeles, CA', 'Chicago, IL', 'Houston, TX',
      'Phoenix, AZ', 'Miami, FL', 'Seattle, WA', 'Boston, MA',
      'Atlanta, GA', 'Denver, CO', 'Austin, TX', 'San Francisco, CA'
    ];

    const jobTitles = [
      'Software Engineer', 'Digital Marketer', 'Content Creator', 'Photographer',
      'Designer', 'Entrepreneur', 'Consultant', 'Artist', 'Writer', 'Teacher'
    ];

    // Generate 8-12 social media accounts
    const numAccounts = Math.floor(Math.random() * 5) + 8;
    const selectedPlatforms = [...platformsData].sort(() => 0.5 - Math.random()).slice(0, numAccounts);

    return selectedPlatforms.map((platform, index) => {
      // Generate platform-specific username variations
      let platformUsername = username;
      if (Math.random() > 0.3) { // 70% chance of variation
        const variations = [
          `${username}_official`,
          `${username}.${platform.name.toLowerCase()}`,
          `${username}${Math.floor(Math.random() * 99) + 1}`,
          `real_${username}`,
          `${username}_${new Date().getFullYear()}`
        ];
        platformUsername = variations[Math.floor(Math.random() * variations.length)];
      }

      return {
        platform: platform.name,
        icon: platform.icon,
        color: platform.color,
        username: platformUsername,
        profileUrl: `${platform.baseUrl}${platformUsername}`,
        name: baseName,
        email: baseEmail,
        phone: `+1 (${basePhone.slice(0,3)}) ${basePhone.slice(3,6)}-${basePhone.slice(6)}`,
        location: locations[Math.floor(Math.random() * locations.length)],
        followers: Math.floor(Math.random() * 100000) + 500,
        following: Math.floor(Math.random() * 5000) + 100,
        posts: Math.floor(Math.random() * 2000) + 50,
        likes: Math.floor(Math.random() * 50000) + 1000,
        joinedDate: new Date(2015 + Math.floor(Math.random() * 9), Math.floor(Math.random() * 12), Math.floor(Math.random() * 28) + 1).toLocaleDateString(),
        lastActive: `${Math.floor(Math.random() * 30) + 1} days ago`,
        verified: Math.random() > 0.7,
        isPrivate: Math.random() > 0.6,
        bio: `${jobTitles[Math.floor(Math.random() * jobTitles.length)]} | ${baseName} | Living in ${locations[Math.floor(Math.random() * locations.length)].split(',')[0]}`,
        profileImage: `https://ui-avatars.com/api/?name=${encodeURIComponent(baseName)}&background=random&size=200&font-size=0.6`
      };
    });
  };

  const handleSearch = async () => {
    if (!searchInput.trim()) {
      setError('Please enter a search term');
      return;
    }

    setError('');
    setIsLoading(true);
    setResults(null);

    try {
      // Simulate API call delay
      await new Promise(resolve => setTimeout(resolve, 1500));

      const mockResults = generateConsistentData(searchInput.trim(), searchType);
      setResults(mockResults);
    } catch (err) {
      setError(err.message);
    } finally {
      setIsLoading(false);
    }
  };

  const exportToPDF = () => {
    const printWindow = window.open('', '', 'height=800,width=1200');
    if (!printWindow) return;

    printWindow.document.write(`
      <html>
        <head>
          <title>Social Media Intelligence Report</title>
          <style>
            body {
              font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
              margin: 20px;
              color: #333;
              line-height: 1.6;
            }
            .header {
              text-align: center;
              margin-bottom: 40px;
              border-bottom: 2px solid #4F46E5;
              padding-bottom: 20px;
            }
            .header h1 { color: #4F46E5; margin-bottom: 10px; }
            .platform {
              border: 1px solid #e5e7eb;
              margin-bottom: 25px;
              padding: 20px;
              border-radius: 12px;
              box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            }
            .platform-name {
              font-size: 20px;
              font-weight: bold;
              color: #1f2937;
              margin-bottom: 15px;
              display: flex;
              align-items: center;
            }
            .info-row {
              margin: 8px 0;
              display: flex;
            }
            .label {
              font-weight: 600;
              min-width: 120px;
              color: #4B5563;
            }
            .value { color: #111827; }
            .stats {
              display: grid;
              grid-template-columns: repeat(3, 1fr);
              gap: 15px;
              margin: 15px 0;
              padding: 15px;
              background: #f9fafb;
              border-radius: 8px;
            }
            .stat { text-align: center; }
            .stat-number { font-weight: bold; font-size: 18px; color: #4F46E5; }
            .stat-label { font-size: 12px; color: #6B7280; text-transform: uppercase; }
          </style>
        </head>
        <body>
          <div class="header">
            <h1>🛡️ Social Media Intelligence Report</h1>
            <p><strong>Search Query:</strong> ${searchInput} (${searchType})</p>
            <p><strong>Generated on:</strong> ${new Date().toLocaleDateString()}</p>
            <p><strong>Total Platforms Found:</strong> ${results?.length || 0}</p>
          </div>
          ${results?.map(result => `
            <div class="platform">
              <div class="platform-name">
                ${result.icon} ${result.platform}
                ${result.verified ? ' ✅ Verified' : ''}
              </div>
              <div class="info-row">
                <span class="label">Name:</span>
                <span class="value">${result.name}</span>
              </div>
              <div class="info-row">
                <span class="label">Username:</span>
                <span class="value">@${result.username}</span>
              </div>
              <div class="info-row">
                <span class="label">Profile URL:</span>
                <span class="value">${result.profileUrl}</span>
              </div>
              <div class="info-row">
                <span class="label">Email:</span>
                <span class="value">${result.email}</span>
              </div>
              <div class="info-row">
                <span class="label">Phone:</span>
                <span class="value">${result.phone}</span>
              </div>
              <div class="info-row">
                <span class="label">Location:</span>
                <span class="value">${result.location}</span>
              </div>
              <div class="stats">
                <div class="stat">
                  <div class="stat-number">${result.followers.toLocaleString()}</div>
                  <div class="stat-label">Followers</div>
                </div>
                <div class="stat">
                  <div class="stat-number">${result.posts}</div>
                  <div class="stat-label">Posts</div>
                </div>
                <div class="stat">
                  <div class="stat-number">${result.likes.toLocaleString()}</div>
                  <div class="stat-label">Likes</div>
                </div>
              </div>
              <div class="info-row">
                <span class="label">Joined:</span>
                <span class="value">${result.joinedDate}</span>
              </div>
              <div class="info-row">
                <span class="label">Bio:</span>
                <span class="value">${result.bio}</span>
              </div>
            </div>
          `).join('')}
        </body>
      </html>
    `);
    printWindow.document.close();
    printWindow.print();
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
      {/* Enhanced animated background */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute -top-40 -right-40 w-80 h-80 bg-purple-500 rounded-full mix-blend-multiply filter blur-xl opacity-20 animate-pulse"></div>
        <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-cyan-500 rounded-full mix-blend-multiply filter blur-xl opacity-20 animate-pulse animation-delay-2000"></div>
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-blue-500 rounded-full mix-blend-multiply filter blur-xl opacity-10 animate-pulse animation-delay-4000"></div>
      </div>

      <div className="relative z-10 container mx-auto px-4 py-8">
        {/* Enhanced Header */}
        <div className="text-center mb-12">
          <div className="flex items-center justify-center mb-6">
            <div className="relative">
              <Shield className="w-16 h-16 text-cyan-400 mr-4 animate-pulse" />
              <div className="absolute -top-2 -right-2 w-6 h-6 bg-green-500 rounded-full flex items-center justify-center">
                <Eye className="w-3 h-3 text-white" />
              </div>
            </div>
            <h1 className="text-5xl md:text-6xl font-bold text-white">
              Social Media <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-purple-400 to-pink-400 animate-pulse">Intel Pro</span>
            </h1>
          </div>
          <p className="text-gray-300 text-xl mb-4">Advanced Social Media Intelligence & Investigation Platform</p>
          <div className="flex justify-center items-center space-x-4 text-sm text-cyan-400">
            <span className="flex items-center"><Globe className="w-4 h-4 mr-1" />12+ Platforms</span>
            <span className="flex items-center"><Shield className="w-4 h-4 mr-1" />Secure</span>
            <span className="flex items-center"><Eye className="w-4 h-4 mr-1" />Real-time</span>
          </div>
        </div>

        {/* Enhanced Search Section */}
        <div className="max-w-5xl mx-auto mb-12">
          <div className="bg-white/10 backdrop-blur-lg rounded-3xl p-8 border border-white/20 shadow-2xl hover:shadow-cyan-500/20 transition-all duration-500">
            <div className="flex flex-col md:flex-row gap-4 mb-6">
              <div className="flex-1 relative">
                <input
                  type="text"
                  placeholder={
                    searchType === 'phone' ? "Enter 10-digit phone number..." :
                    searchType === 'email' ? "Enter email address..." :
                    "Enter username (min 3 characters)..."
                  }
                  className="w-full px-6 py-5 bg-white/10 backdrop-blur-sm border border-white/20 rounded-2xl text-white placeholder-gray-400 focus:outline-none focus:border-cyan-400 focus:ring-4 focus:ring-cyan-400/30 transition-all duration-300 text-lg hover:bg-white/15"
                  value={searchInput}
                  onChange={(e) => {
                    setSearchInput(e.target.value);
                    setError('');
                  }}
                  onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
                />
                {searchType === 'phone' && (
                  <div className="absolute right-4 top-1/2 transform -translate-y-1/2 text-gray-400 text-sm">
                    {searchInput.replace(/\D/g, '').length}/10
                  </div>
                )}
              </div>
              <select
                className="px-6 py-5 bg-white/10 backdrop-blur-sm border border-white/20 rounded-2xl text-white focus:outline-none focus:border-cyan-400 focus:ring-4 focus:ring-cyan-400/30 transition-all duration-300 hover:bg-white/15 text-lg"
                value={searchType}
                onChange={(e) => {
                  setSearchType(e.target.value);
                  setSearchInput('');
                  setError('');
                }}
              >
                <option value="username" className="bg-gray-800 text-white">👤 Username</option>
                <option value="email" className="bg-gray-800 text-white">📧 Email</option>
                <option value="phone" className="bg-gray-800 text-white">📱 Phone</option>
              </select>
            </div>

            {error && (
              <div className="mb-4 p-4 bg-red-500/20 border border-red-500/50 rounded-xl text-red-300 flex items-center">
                <span className="mr-2">⚠️</span>
                {error}
              </div>
            )}

            <button
              onClick={handleSearch}
              disabled={!searchInput.trim() || isLoading}
              className="w-full bg-gradient-to-r from-cyan-500 via-purple-500 to-pink-500 hover:from-cyan-600 hover:via-purple-600 hover:to-pink-600 disabled:opacity-50 disabled:cursor-not-allowed text-white font-bold py-5 px-8 rounded-2xl transition-all duration-300 transform hover:scale-[1.02] hover:shadow-xl hover:shadow-cyan-500/30 flex items-center justify-center gap-3 text-lg"
            >
              {isLoading ? (
                <>
                  <div className="animate-spin rounded-full h-6 w-6 border-3 border-white border-t-transparent"></div>
                  <span className="animate-pulse">Investigating...</span>
                </>
              ) : (
                <>
                  <Search className="w-6 h-6" />
                  🔍 Start Deep Investigation
                </>
              )}
            </button>
          </div>
        </div>

        {/* Enhanced Results Section */}
        {results && (
          <div className="max-w-7xl mx-auto">
            <div className="flex flex-col md:flex-row justify-between items-center mb-8 bg-white/10 backdrop-blur-lg rounded-2xl p-6 border border-white/20">
              <div>
                <h2 className="text-3xl font-bold text-white flex items-center gap-3 mb-2">
                  <Eye className="w-8 h-8 text-cyan-400 animate-pulse" />
                  Investigation Complete
                </h2>
                <p className="text-cyan-400 text-lg">
                  Found <span className="font-bold text-white">{results.length}</span> social media profiles for{' '}
                  <span className="font-bold text-white">{results[0]?.name}</span>
                </p>
              </div>
              <button
                onClick={exportToPDF}
                className="bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 text-white font-bold py-3 px-6 rounded-xl transition-all duration-300 transform hover:scale-105 hover:shadow-lg flex items-center gap-2 mt-4 md:mt-0"
              >
                <Download className="w-5 h-5" />
                Export Report
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {results.map((result, index) => (
                <div
                  key={index}
                  className="group bg-white/10 backdrop-blur-lg rounded-3xl p-6 border border-white/20 shadow-xl hover:shadow-2xl hover:shadow-cyan-500/20 transition-all duration-500 transform hover:scale-[1.03] hover:-translate-y-2"
                >
                  {/* Platform Header */}
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center">
                      <div className={`w-14 h-14 bg-gradient-to-br ${result.color} rounded-2xl flex items-center justify-center text-2xl mr-4 group-hover:scale-110 transition-transform duration-300 shadow-lg`}>
                        {result.icon}
                      </div>
                      <div>
                        <h3 className="text-xl font-bold text-white group-hover:text-cyan-400 transition-colors">
                          {result.platform}
                        </h3>
                        <div className="flex items-center space-x-2">
                          {result.verified && (
                            <span className="flex items-center text-xs text-emerald-400 bg-emerald-500/20 px-2 py-1 rounded-full">
                              <Shield className="w-3 h-3 mr-1" />
                              Verified
                            </span>
                          )}
                          {result.isPrivate && (
                            <span className="text-xs text-orange-400 bg-orange-500/20 px-2 py-1 rounded-full">
                              🔒 Private
                            </span>
                          )}
                        </div>
                      </div>
                    </div>
                    <a
                      href={result.profileUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-cyan-400 hover:text-white transition-colors p-2 hover:bg-white/20 rounded-lg"
                    >
                      <ExternalLink className="w-5 h-5" />
                    </a>
                  </div>

                  {/* Profile Info */}
                  <div className="space-y-3 text-gray-300 mb-4">
                    <div className="flex items-center gap-2 group-hover:text-white transition-colors">
                      <User className="w-4 h-4 text-cyan-400" />
                      <span className="text-sm font-semibold">Name:</span>
                      <span className="text-white font-medium">{result.name}</span>
                    </div>

                    <div className="flex items-center gap-2 group-hover:text-white transition-colors">
                      <span className="text-cyan-400 font-bold">@</span>
                      <span className="text-white font-mono text-sm">{result.username}</span>
                    </div>

                    <div className="flex items-center gap-2 group-hover:text-white transition-colors">
                      <Mail className="w-4 h-4 text-cyan-400" />
                      <span className="text-white text-sm break-all">{result.email}</span>
                    </div>

                    <div className="flex items-center gap-2 group-hover:text-white transition-colors">
                      <Phone className="w-4 h-4 text-cyan-400" />
                      <span className="text-white">{result.phone}</span>
                    </div>

                    <div className="flex items-center gap-2 group-hover:text-white transition-colors">
                      <MapPin className="w-4 h-4 text-cyan-400" />
                      <span className="text-white text-sm">{result.location}</span>
                    </div>
                  </div>

                  {/* Stats Grid */}
                  <div className="grid grid-cols-2 gap-3 mb-4">
                    <div className="bg-white/5 rounded-lg p-3 text-center hover:bg-white/10 transition-all">
                      <Users className="w-4 h-4 text-cyan-400 mx-auto mb-1" />
                      <div className="text-white font-bold">{result.followers.toLocaleString()}</div>
                      <div className="text-xs text-gray-400">Followers</div>
                    </div>
                    <div className="bg-white/5 rounded-lg p-3 text-center hover:bg-white/10 transition-all">
                      <MessageCircle className="w-4 h-4 text-purple-400 mx-auto mb-1" />
                      <div className="text-white font-bold">{result.posts}</div>
                      <div className="text-xs text-gray-400">Posts</div>
                    </div>
                    <div className="bg-white/5 rounded-lg p-3 text-center hover:bg-white/10 transition-all">
                      <Heart className="w-4 h-4 text-red-400 mx-auto mb-1" />
                      <div className="text-white font-bold">{result.likes.toLocaleString()}</div>
                      <div className="text-xs text-gray-400">Likes</div>
                    </div>
                    <div className="bg-white/5 rounded-lg p-3 text-center hover:bg-white/10 transition-all">
                      <Calendar className="w-4 h-4 text-green-400 mx-auto mb-1" />
                      <div className="text-white font-bold text-xs">{result.joinedDate}</div>
                      <div className="text-xs text-gray-400">Joined</div>
                    </div>
                  </div>

                  {/* Bio */}
                  <div className="bg-white/5 rounded-xl p-3 mb-4 group-hover:bg-white/10 transition-all">
                    <p className="text-sm text-gray-300 group-hover:text-white transition-colors">
                      <span className="font-semibold text-cyan-400">Bio:</span> {result.bio}
                    </p>
                  </div>

                  {/* Last Active */}
                  <div className="text-center">
                    <span className="text-xs text-gray-400">
                      Last active: <span className="text-cyan-400">{result.lastActive}</span>
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Enhanced Footer */}
        <div className="text-center mt-20 space-y-4">
          <div className="flex justify-center items-center space-x-6 text-gray-400">
            <span className="flex items-center"><Shield className="w-4 h-4 mr-2" />Secure & Private</span>
            <span className="flex items-center"><Eye className="w-4 h-4 mr-2" />Real-time Intelligence</span>
            <span className="flex items-center"><Globe className="w-4 h-4 mr-2" />Global Database</span>
          </div>
          <p className="text-sm text-gray-500">
            ⚡ Powered by Advanced AI Intelligence | For Educational & Research Purposes Only
          </p>
          <div className="text-xs text-gray-600 max-w-2xl mx-auto">
            This tool generates mock data for demonstration purposes. Real social media investigation should only be conducted
            with proper authorization and for legitimate purposes.
          </div>
        </div>
      </div>
    </div>
  );
};

export default SocialMediaFinder;